package com.fryderykrott.receiptcarerfinal.chips;

public class GroupChoosingForSearchChipContainer {
}
