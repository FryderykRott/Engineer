package com.fryderykrott.receiptcarerfinal.alertdialogs;

public class GroypChossingForSearchAlertDialog {
}
