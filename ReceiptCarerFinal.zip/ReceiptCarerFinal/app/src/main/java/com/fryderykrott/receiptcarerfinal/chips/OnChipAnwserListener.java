package com.fryderykrott.receiptcarerfinal.chips;

public interface OnChipAnwserListener {
    public void onChipAnwser();
}
